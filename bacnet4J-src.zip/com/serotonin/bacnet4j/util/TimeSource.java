package com.serotonin.bacnet4j.util;

public interface TimeSource {
    long currentTimeMillis();
}
