package com.serotonin.bacnet4j.client.cylon;

import com.serotonin.bacnet4j.LocalDevice;
import com.serotonin.bacnet4j.RemoteDevice;
import com.serotonin.bacnet4j.exception.BACnetException;
import com.serotonin.bacnet4j.npdu.ip.IpNetwork;
import com.serotonin.bacnet4j.service.confirmed.ConfirmedEventNotificationRequest;
import com.serotonin.bacnet4j.transport.Transport;
import com.serotonin.bacnet4j.type.constructed.Address;
import com.serotonin.bacnet4j.type.constructed.DateTime;
import com.serotonin.bacnet4j.type.constructed.StatusFlags;
import com.serotonin.bacnet4j.type.constructed.TimeStamp;
import com.serotonin.bacnet4j.type.enumerated.EventState;
import com.serotonin.bacnet4j.type.enumerated.EventType;
import com.serotonin.bacnet4j.type.enumerated.NotifyType;
import com.serotonin.bacnet4j.type.enumerated.ObjectType;
import com.serotonin.bacnet4j.type.enumerated.PropertyIdentifier;
import com.serotonin.bacnet4j.type.notificationParameters.ChangeOfValue;
import com.serotonin.bacnet4j.type.primitive.Boolean;
import com.serotonin.bacnet4j.type.primitive.CharacterString;
import com.serotonin.bacnet4j.type.primitive.ObjectIdentifier;
import com.serotonin.bacnet4j.type.primitive.Real;
import com.serotonin.bacnet4j.type.primitive.UnsignedInteger;
import com.serotonin.bacnet4j.util.RequestUtils;

public class SendEvent {
    static LocalDevice localDevice;
    static RemoteDevice remoteDevice;
    static int processId = 123;

    public static void main(String[] args) throws Exception {
        IpNetwork network = new IpNetwork("255.255.255.255", 47809);
        Transport transport = new Transport(network);
        localDevice = new LocalDevice(1968, transport);
        try {
            localDevice.initialize();

            //            remoteDevice = localDevice.findRemoteDevice(new Address(36, (byte) 1), new OctetString("89.101.141.54"),
            //                    1001);
            //            remoteDevice = localDevice.findRemoteDevice(new Address("localhost", 47808), null, 1970);
            remoteDevice = localDevice.findRemoteDevice(new Address(0, "99.247.66.223", 0xFAC0), null, 1970);

            ObjectIdentifier nc1 = new ObjectIdentifier(ObjectType.notificationClass, 1);
            ObjectIdentifier nc2 = new ObjectIdentifier(ObjectType.notificationClass, 2);

            ConfirmedEventNotificationRequest raise = new ConfirmedEventNotificationRequest(new UnsignedInteger(2597),
                    new ObjectIdentifier(ObjectType.device, 1001), nc1, new TimeStamp(new DateTime(
                            System.currentTimeMillis())), new UnsignedInteger(1), new UnsignedInteger(150),
                    EventType.changeOfValue, new CharacterString("Test notification"), NotifyType.event, new Boolean(
                            true), EventState.normal, EventState.offnormal, new ChangeOfValue(new Real(12),
                            new StatusFlags(true, false, false, false)));

            ConfirmedEventNotificationRequest rtn = new ConfirmedEventNotificationRequest(new UnsignedInteger(2597),
                    new ObjectIdentifier(ObjectType.device, 1001), nc1, new TimeStamp(new DateTime(
                            System.currentTimeMillis())), new UnsignedInteger(1), new UnsignedInteger(150),
                    EventType.changeOfValue, new CharacterString("Test notification"), NotifyType.event, new Boolean(
                            true), EventState.offnormal, EventState.normal, new ChangeOfValue(new Real(12),
                            new StatusFlags(true, false, false, false)));

            localDevice.send(remoteDevice, rtn);
            localDevice.send(remoteDevice, raise);
            //            localDevice.send(remoteDevice, rtn);

            //            dumpNC(nc1);
            //            dumpNC(nc2);
        }
        finally {
            localDevice.terminate();
        }
    }

    static void dumpNC(ObjectIdentifier oid) throws BACnetException {
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.notificationClass));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.priority));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.ackRequired));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.recipientList));
    }
}
