package com.serotonin.bacnet4j.client.cylon;

import com.serotonin.bacnet4j.LocalDevice;
import com.serotonin.bacnet4j.RemoteDevice;
import com.serotonin.bacnet4j.npdu.ip.IpNetwork;
import com.serotonin.bacnet4j.transport.Transport;
import com.serotonin.bacnet4j.type.constructed.Address;
import com.serotonin.bacnet4j.type.primitive.OctetString;
import com.serotonin.bacnet4j.util.DiscoveryUtils;

public class Test {
    public static void main(String[] args) throws Exception {
        IpNetwork network = new IpNetwork("255.255.255.255", 47809);
        Transport transport = new Transport(network);
        LocalDevice localDevice = new LocalDevice(1968, transport);
        try {
            localDevice.initialize();

            RemoteDevice d = localDevice.findRemoteDevice(new Address(36, (byte) 1), new OctetString("89.101.141.54"),
                    1001);
            DiscoveryUtils.getExtendedDeviceInformation(localDevice, d);

            System.out.println(d.getVendorId());
            System.out.println(d.getModelName());

            //            //            SequenceOf<ObjectIdentifier> oids = RequestUtils.getObjectList(localDevice, d);
            //            //            System.out.println(oids);
            //
            //            ObjectIdentifier tl1 = new ObjectIdentifier(ObjectType.trendLog, 1);
            //            //            ObjectIdentifier tl2 = new ObjectIdentifier(ObjectType.trendLog, 2);
            //
            //            //            System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, d, tl1,
            //            //                    PropertyIdentifier.bufferSize));
            //            //            System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, d, tl1,
            //            //                    PropertyIdentifier.recordCount));
            //            //            System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, d, tl1,
            //            //                    PropertyIdentifier.totalRecordCount));
            //            System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, d, tl1,
            //                    PropertyIdentifier.logDeviceObjectProperty));
            //
            //            //            ByTime byTime = new ByTime(new DateTime(System.currentTimeMillis() - 1000 * 60 * 60 * 24),
            //            //                    new SignedInteger(50));
            //
            //            long startTime = 0;
            //            while (true) {
            //                System.out.println("Request ***");
            //                ByTime byTime = new ByTime(new DateTime(startTime), new SignedInteger(10));
            //                ReadRangeRequest req = new ReadRangeRequest(tl1, PropertyIdentifier.logBuffer, null, byTime);
            //                ReadRangeAck res = localDevice.send(d, req);
            //
            //                @SuppressWarnings("unchecked")
            //                SequenceOf<LogRecord> records = (SequenceOf<LogRecord>) res.getItemData();
            //                for (LogRecord record : records) {
            //                    System.out.println("  " + record.getEncodable() + "@" + record.getTimestamp());
            //                    startTime = record.getTimestamp().getTimeMillis();
            //                }
            //
            //                if (res.getItemCount().intValue() == 0)
            //                    break;
            //            }
        }
        finally {
            localDevice.terminate();
        }
    }
}
