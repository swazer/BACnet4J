package com.serotonin.bacnet4j.client.cylon;

import com.serotonin.bacnet4j.LocalDevice;
import com.serotonin.bacnet4j.RemoteDevice;
import com.serotonin.bacnet4j.exception.BACnetException;
import com.serotonin.bacnet4j.npdu.ip.IpNetwork;
import com.serotonin.bacnet4j.transport.Transport;
import com.serotonin.bacnet4j.type.constructed.Address;
import com.serotonin.bacnet4j.type.constructed.Destination;
import com.serotonin.bacnet4j.type.constructed.EventTransitionBits;
import com.serotonin.bacnet4j.type.constructed.Recipient;
import com.serotonin.bacnet4j.type.enumerated.ObjectType;
import com.serotonin.bacnet4j.type.enumerated.PropertyIdentifier;
import com.serotonin.bacnet4j.type.primitive.ObjectIdentifier;
import com.serotonin.bacnet4j.type.primitive.OctetString;
import com.serotonin.bacnet4j.type.primitive.UnsignedInteger;
import com.serotonin.bacnet4j.util.DiscoveryUtils;
import com.serotonin.bacnet4j.util.RequestUtils;

public class NotifClass {
    static LocalDevice localDevice;
    static RemoteDevice remoteDevice;
    static int processId = 123;

    public static void main(String[] args) throws Exception {
        IpNetwork network = new IpNetwork("255.255.255.255", 47809);
        Transport transport = new Transport(network);
        localDevice = new LocalDevice(1968, transport);
        try {
            localDevice.initialize();

            //          remoteDevice = localDevice.findRemoteDevice(new Address(36, (byte) 1), new OctetString("89.101.141.54"),
            //          1001);
            remoteDevice = localDevice.findRemoteDevice(new Address(36, (byte) 2), new OctetString("89.101.141.54"),
                    1002);
            //            remoteDevice = localDevice.findRemoteDevice(new Address("108.9.141.98", 47808), null, 10000);

            DiscoveryUtils.getExtendedDeviceInformation(localDevice, remoteDevice);
            System.out.println(remoteDevice.getVendorId());
            System.out.println(remoteDevice.getModelName());

            ObjectIdentifier nc1 = new ObjectIdentifier(ObjectType.notificationClass, 1);
            ObjectIdentifier nc2 = new ObjectIdentifier(ObjectType.notificationClass, 2);

            //            dumpNC(nc1);
            //            dumpNC(nc2);

            //            subscribeNC(nc1);
            //            dumpNC(nc1);
        }
        finally {
            localDevice.terminate();
        }
    }

    static void dumpNC(ObjectIdentifier oid) throws BACnetException {
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.notificationClass));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.priority));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.ackRequired));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.recipientList));
    }

    static void subscribeNC(ObjectIdentifier oid) throws BACnetException {
        //        Recipient recipient = new Recipient(new ObjectIdentifier(ObjectType.device, 376));
        //        EventTransitionBits transitions = new EventTransitionBits(true, true, true);
        //        Destination destination = new Destination(recipient, new UnsignedInteger(1),
        //                new com.serotonin.bacnet4j.type.primitive.Boolean(true), transitions);
        //        RequestUtils.writeProperty(localDevice, remoteDevice, oid, PropertyIdentifier.recipientList, destination);

        Recipient recipient = new Recipient(localDevice.getConfiguration().getId());
        EventTransitionBits transitions = new EventTransitionBits(true, true, true);
        Destination destination = new Destination(recipient, new UnsignedInteger(processId),
                new com.serotonin.bacnet4j.type.primitive.Boolean(true), transitions);

        //        RequestUtils.addListElement(localDevice, remoteDevice, oid, PropertyIdentifier.recipientList, destination);
        RequestUtils.removeListElement(localDevice, remoteDevice, oid, PropertyIdentifier.recipientList, destination);
    }
}
