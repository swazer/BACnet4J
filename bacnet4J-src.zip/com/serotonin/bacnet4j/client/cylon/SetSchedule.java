package com.serotonin.bacnet4j.client.cylon;

import java.util.ArrayList;
import java.util.List;

import com.serotonin.bacnet4j.LocalDevice;
import com.serotonin.bacnet4j.RemoteDevice;
import com.serotonin.bacnet4j.enums.DayOfWeek;
import com.serotonin.bacnet4j.enums.Month;
import com.serotonin.bacnet4j.exception.BACnetException;
import com.serotonin.bacnet4j.npdu.ip.IpNetwork;
import com.serotonin.bacnet4j.transport.Transport;
import com.serotonin.bacnet4j.type.constructed.Address;
import com.serotonin.bacnet4j.type.constructed.DailySchedule;
import com.serotonin.bacnet4j.type.constructed.DateRange;
import com.serotonin.bacnet4j.type.constructed.PropertyValue;
import com.serotonin.bacnet4j.type.constructed.SequenceOf;
import com.serotonin.bacnet4j.type.constructed.SpecialEvent;
import com.serotonin.bacnet4j.type.constructed.TimeValue;
import com.serotonin.bacnet4j.type.enumerated.ObjectType;
import com.serotonin.bacnet4j.type.enumerated.PropertyIdentifier;
import com.serotonin.bacnet4j.type.primitive.Date;
import com.serotonin.bacnet4j.type.primitive.Enumerated;
import com.serotonin.bacnet4j.type.primitive.Null;
import com.serotonin.bacnet4j.type.primitive.ObjectIdentifier;
import com.serotonin.bacnet4j.type.primitive.OctetString;
import com.serotonin.bacnet4j.type.primitive.Time;
import com.serotonin.bacnet4j.type.primitive.UnsignedInteger;
import com.serotonin.bacnet4j.util.RequestUtils;

//0
//DateRange [startDate=UNSPECIFIED UNSPECIFIED 255, 255, endDate=UNSPECIFIED UNSPECIFIED 255, 255]
//[DailySchedule [daySchedule=[TimeValue [time=9:0:255.255, value=1], TimeValue [time=17:0:255.255, value=0]]], DailySchedule [daySchedule=[TimeValue [time=9:0:255.255, value=1], TimeValue [time=17:0:255.255, value=0]]], DailySchedule [daySchedule=[TimeValue [time=9:0:255.255, value=1], TimeValue [time=17:0:255.255, value=0]]], DailySchedule [daySchedule=[TimeValue [time=9:0:255.255, value=1], TimeValue [time=17:0:255.255, value=0]]], DailySchedule [daySchedule=[TimeValue [time=9:0:255.255, value=1], TimeValue [time=17:0:255.255, value=0]]], DailySchedule [daySchedule=[]], DailySchedule [daySchedule=[]]]
//[]

public class SetSchedule {
    static LocalDevice localDevice;
    static RemoteDevice remoteDevice;

    public static void main(String[] args) throws Exception {
        IpNetwork network = new IpNetwork("255.255.255.255", 47809);
        Transport transport = new Transport(network);
        localDevice = new LocalDevice(1968, transport);
        try {
            localDevice.initialize();

            remoteDevice = localDevice.findRemoteDevice(new Address(36, (byte) 1), new OctetString("89.101.141.54"),
                    1001);

            ObjectIdentifier sch = new ObjectIdentifier(ObjectType.schedule, 1);

            //            writeEmpty(sch);
            //            writeInteger(sch);
            //            writeEnum(sch);
            //            writeBoolean(sch);
            dumpSchedule(sch);
        }
        finally {
            localDevice.terminate();
        }
    }

    static void writeEnum(ObjectIdentifier oid) throws BACnetException {
        List<PropertyValue> props = new ArrayList<PropertyValue>();
        props.add(new PropertyValue(PropertyIdentifier.scheduleDefault, new Enumerated(0)));

        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        Date unspecified = new Date(0, Month.UNSPECIFIED, 0, DayOfWeek.UNSPECIFIED);
        props.add(new PropertyValue(PropertyIdentifier.effectivePeriod, new DateRange(unspecified, unspecified)));

        SequenceOf<DailySchedule> dailies = new SequenceOf<DailySchedule>();
        SequenceOf<TimeValue> tvs = new SequenceOf<TimeValue>();
        tvs.add(new TimeValue(new Time(8, 0, 0, 0), new Enumerated(9)));
        //        tvs.add(new TimeValue(new Time(15, 30, 0, 0), new UnsignedInteger(0)));
        tvs.add(new TimeValue(new Time(15, 30, 0, 0), new Null()));
        dailies.add(new DailySchedule(tvs));

        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(new SequenceOf<TimeValue>()));
        dailies.add(new DailySchedule(new SequenceOf<TimeValue>()));
        props.add(new PropertyValue(PropertyIdentifier.weeklySchedule, dailies));

        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        RequestUtils.writeProperties(localDevice, remoteDevice, oid, props);
    }

    static void writeInteger(ObjectIdentifier oid) throws BACnetException {
        List<PropertyValue> props = new ArrayList<PropertyValue>();
        props.add(new PropertyValue(PropertyIdentifier.scheduleDefault, new UnsignedInteger(0)));

        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        Date unspecified = new Date(0, Month.UNSPECIFIED, 0, DayOfWeek.UNSPECIFIED);
        props.add(new PropertyValue(PropertyIdentifier.effectivePeriod, new DateRange(unspecified, unspecified)));

        SequenceOf<DailySchedule> dailies = new SequenceOf<DailySchedule>();
        SequenceOf<TimeValue> tvs = new SequenceOf<TimeValue>();
        tvs.add(new TimeValue(new Time(8, 0, 0, 0), new UnsignedInteger(1)));
        //        tvs.add(new TimeValue(new Time(15, 30, 0, 0), new UnsignedInteger(0)));
        tvs.add(new TimeValue(new Time(15, 30, 0, 0), new Null()));
        dailies.add(new DailySchedule(tvs));

        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(tvs));
        dailies.add(new DailySchedule(new SequenceOf<TimeValue>()));
        dailies.add(new DailySchedule(new SequenceOf<TimeValue>()));
        props.add(new PropertyValue(PropertyIdentifier.weeklySchedule, dailies));

        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        RequestUtils.writeProperties(localDevice, remoteDevice, oid, props);
    }

    static void writeBoolean(ObjectIdentifier oid) throws BACnetException {
        List<PropertyValue> props = new ArrayList<PropertyValue>();
        //        props.add(new PropertyValue(PropertyIdentifier.scheduleDefault,
        //                new com.serotonin.bacnet4j.type.primitive.Boolean(false)));

        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        //        Date unspecified = new Date(0, Month.UNSPECIFIED, 0, DayOfWeek.UNSPECIFIED);
        //        props.add(new PropertyValue(PropertyIdentifier.effectivePeriod, new DateRange(unspecified, unspecified)));
        //
        //        SequenceOf<DailySchedule> dailies = new SequenceOf<DailySchedule>();
        //        SequenceOf<TimeValue> tvs = new SequenceOf<TimeValue>();
        //        tvs.add(new TimeValue(new Time(8, 0, 0, 0), new com.serotonin.bacnet4j.type.primitive.Boolean(true)));
        //        tvs.add(new TimeValue(new Time(15, 30, 0, 0), new com.serotonin.bacnet4j.type.primitive.Boolean(false)));
        //        //        tvs.add(new TimeValue(new Time(15, 30, 0, 0), new Null()));
        //        dailies.add(new DailySchedule(tvs));
        //        dailies.add(new DailySchedule(tvs));
        //        dailies.add(new DailySchedule(tvs));
        //        dailies.add(new DailySchedule(tvs));
        //        dailies.add(new DailySchedule(tvs));
        //        dailies.add(new DailySchedule(new SequenceOf<TimeValue>()));
        //        dailies.add(new DailySchedule(new SequenceOf<TimeValue>()));
        //        props.add(new PropertyValue(PropertyIdentifier.weeklySchedule, dailies));

        //        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        RequestUtils.writeProperties(localDevice, remoteDevice, oid, props);
    }

    static void writeEmpty(ObjectIdentifier oid) throws BACnetException {
        List<PropertyValue> props = new ArrayList<PropertyValue>();
        props.add(new PropertyValue(PropertyIdentifier.scheduleDefault,
                new com.serotonin.bacnet4j.type.primitive.Boolean(false)));

        Date unspecified = new Date(0, Month.UNSPECIFIED, 0, DayOfWeek.UNSPECIFIED);
        props.add(new PropertyValue(PropertyIdentifier.effectivePeriod, new DateRange(unspecified, unspecified)));

        SequenceOf<DailySchedule> dailies = new SequenceOf<DailySchedule>();
        DailySchedule daily = new DailySchedule(new SequenceOf<TimeValue>());
        for (int i = 0; i < 7; i++)
            dailies.add(daily);
        props.add(new PropertyValue(PropertyIdentifier.weeklySchedule, dailies));

        props.add(new PropertyValue(PropertyIdentifier.exceptionSchedule, new SequenceOf<SpecialEvent>()));

        RequestUtils.writeProperties(localDevice, remoteDevice, oid, props);
    }

    static void dumpSchedule(ObjectIdentifier oid) throws BACnetException {
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.scheduleDefault));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.effectivePeriod));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.weeklySchedule));
        System.out.println(RequestUtils.sendReadPropertyAllowNull(localDevice, remoteDevice, oid,
                PropertyIdentifier.exceptionSchedule));
    }
}
