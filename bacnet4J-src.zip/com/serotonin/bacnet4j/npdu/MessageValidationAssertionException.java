package com.serotonin.bacnet4j.npdu;

public class MessageValidationAssertionException extends Exception {
    private static final long serialVersionUID = -1;

    public MessageValidationAssertionException(String message) {
        super(message);
    }
}
