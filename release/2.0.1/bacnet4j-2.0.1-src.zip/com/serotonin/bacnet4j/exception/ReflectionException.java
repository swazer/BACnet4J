package com.serotonin.bacnet4j.exception;

public class ReflectionException extends BACnetException {
    private static final long serialVersionUID = 1L;

    public ReflectionException(Throwable cause) {
        super(cause);
    }
}
